package kr.human.di.vo;

public interface Encryption {
    public void encryptData();
}