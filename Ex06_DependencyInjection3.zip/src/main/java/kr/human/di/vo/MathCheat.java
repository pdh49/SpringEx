package kr.human.di.vo;

public class MathCheat {
	public void mathCheating() {
		System.out.println("나는 수학 부정행위를 진술했습니다.");
	}
}
