package kr.human.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootSecurityEx09ApplicationTests {

	@Test
	void contextLoads() {
	}

}
