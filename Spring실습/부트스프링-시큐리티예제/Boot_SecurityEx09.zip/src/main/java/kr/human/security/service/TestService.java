package kr.human.security.service;

public interface TestService {
	String today();
}

