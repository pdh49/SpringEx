package kr.top2blue.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMavenSecurityEx04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
