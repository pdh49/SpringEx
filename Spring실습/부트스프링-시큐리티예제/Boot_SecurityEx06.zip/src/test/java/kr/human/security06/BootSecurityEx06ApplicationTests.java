package kr.human.security06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootSecurityEx06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
