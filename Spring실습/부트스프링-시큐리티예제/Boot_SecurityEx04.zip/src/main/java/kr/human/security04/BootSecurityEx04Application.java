package kr.human.security04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSecurityEx04Application {

	public static void main(String[] args) {
		SpringApplication.run(BootSecurityEx04Application.class, args);
	}

}
