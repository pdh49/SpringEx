package kr.human.security07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSecurityEx07Application {

	public static void main(String[] args) {
		SpringApplication.run(BootSecurityEx07Application.class, args);
	}

}
