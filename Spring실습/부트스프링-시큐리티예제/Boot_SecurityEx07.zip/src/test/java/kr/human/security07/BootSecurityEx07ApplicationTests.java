package kr.human.security07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootSecurityEx07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
