package kr.human.security05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootSecurityEx05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
