package kr.green.member.dao;

public interface MemberRoleDAO {
	void insert(String userid);
}
