package kr.human.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSwaggerEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(BootSwaggerEx01Application.class, args);
	}

}
