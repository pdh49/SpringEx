package kr.human.ex06.service;

import java.util.Date;

public interface TestService {
	String selectNow();
	Date   selectToday();
}
