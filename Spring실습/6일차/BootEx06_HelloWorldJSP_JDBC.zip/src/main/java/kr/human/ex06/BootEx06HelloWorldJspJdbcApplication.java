package kr.human.ex06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx06HelloWorldJspJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx06HelloWorldJspJdbcApplication.class, args);
	}

}
