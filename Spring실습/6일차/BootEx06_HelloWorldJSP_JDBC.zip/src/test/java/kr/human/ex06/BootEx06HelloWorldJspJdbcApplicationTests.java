package kr.human.ex06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx06HelloWorldJspJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
