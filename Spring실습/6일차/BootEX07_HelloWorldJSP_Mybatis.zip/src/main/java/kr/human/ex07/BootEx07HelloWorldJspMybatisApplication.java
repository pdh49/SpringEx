package kr.human.ex07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx07HelloWorldJspMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx07HelloWorldJspMybatisApplication.class, args);
	}

}
