package kr.human.ex02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableAutoConfiguration
//@ComponentScan("kr.human.ex02")
public class BootEx02HelloWorldFreeMarkerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx02HelloWorldFreeMarkerApplication.class, args);
	}

}
