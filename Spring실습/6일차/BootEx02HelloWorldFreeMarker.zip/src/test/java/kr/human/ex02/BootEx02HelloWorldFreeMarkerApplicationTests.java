package kr.human.ex02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx02HelloWorldFreeMarkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
