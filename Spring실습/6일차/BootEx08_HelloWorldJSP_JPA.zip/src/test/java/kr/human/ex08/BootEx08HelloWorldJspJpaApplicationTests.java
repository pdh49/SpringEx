package kr.human.ex08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx08HelloWorldJspJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
