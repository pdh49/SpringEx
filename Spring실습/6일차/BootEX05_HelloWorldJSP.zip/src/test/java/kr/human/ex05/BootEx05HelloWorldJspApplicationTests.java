package kr.human.ex05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx05HelloWorldJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
