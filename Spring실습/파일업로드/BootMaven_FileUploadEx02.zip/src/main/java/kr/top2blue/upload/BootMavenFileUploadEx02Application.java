package kr.top2blue.upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMavenFileUploadEx02Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMavenFileUploadEx02Application.class, args);
	}

}
