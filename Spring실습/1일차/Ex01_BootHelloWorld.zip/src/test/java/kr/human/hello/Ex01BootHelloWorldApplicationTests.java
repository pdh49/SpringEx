package kr.human.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex01BootHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
