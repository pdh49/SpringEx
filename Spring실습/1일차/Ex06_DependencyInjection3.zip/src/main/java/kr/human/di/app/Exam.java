package kr.human.di.app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.di.vo.Student;

public class Exam {
	public static void main(String[] args) {
		AbstractApplicationContext context = 
				new ClassPathXmlApplicationContext("beans.xml");
		
		Student student1 = context.getBean("studentAish", Student.class);
		System.out.println(student1.getId()+"("+student1.getStudenName() +")");
		
		context.close();
	}

		
		
}
