package kr.human.di.vo;

public class MathCheat {

		public void mathCheating() {
			System.out.println("And i Have Stated Math Cheating");
		}
}
