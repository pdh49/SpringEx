package kr.human.di.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import kr.human.di.vo.Student;

@Configuration
public class ExamConfig {

	//생성자에 의한 주입
	@Bean(name="student01")
	public Student student1() {
		return new Student(1234,"한사람");
	}
	
	//Setter에 의한 주입
	@Bean(name="student02")
	public Student student2() {
		Student student = new Student();
		student.setId(1111);
		student.setStudenName("하하하하하");
		return student;
	}
	
}
