package kr.human.di.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Student2{

		private int id;
		private MathCheat mathCheat;
		
		public void cheating() {
			System.out.println("My Id is : " +id);
			
			mathCheat.mathCheating();
		}
}
