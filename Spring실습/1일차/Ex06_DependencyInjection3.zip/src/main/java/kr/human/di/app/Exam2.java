package kr.human.di.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.di.config.ExamConfig;
import kr.human.di.vo.Student;

public class Exam2 {
	public static void main(String[] args) {
		AbstractApplicationContext context = 
				new AnnotationConfigApplicationContext(ExamConfig.class);
		
		Student examConfig = context.getBean("student01", Student.class);
		System.out.println(examConfig);
		
		
		Student examConfig2 = context.getBean("student02", Student.class);
		System.out.println(examConfig2);
		
		context.close();
	}

		
		
}
