package kr.human.di.app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.di.vo.Student3;

public class Exam3 {
	public static void main(String[] args) {
		AbstractApplicationContext context =
				new ClassPathXmlApplicationContext("Student3.xml");
		
		Student3 student3 = context.getBean("studentAmiya",Student3.class);
		student3.displayInfo();
		Student3 student4 = context.getBean("studentAmiya2",Student3.class);
		student4.displayInfo();
	
	}
}
