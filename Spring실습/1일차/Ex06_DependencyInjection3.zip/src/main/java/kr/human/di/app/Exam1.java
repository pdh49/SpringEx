package kr.human.di.app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.di.vo.Student2;

public class Exam1 {
	public static void main(String[] args) {
		AbstractApplicationContext context = 
				new ClassPathXmlApplicationContext("Student2.xml");
		
		Student2 student1 = context.getBean("student",Student2.class);
		student1.cheating();
		
		Student2 student2 = context.getBean("student1",Student2.class);
		student2.cheating();

		
		context.close();
	}

		
		
}
