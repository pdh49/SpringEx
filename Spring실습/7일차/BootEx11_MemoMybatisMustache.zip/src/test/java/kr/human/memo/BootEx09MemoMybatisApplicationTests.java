package kr.human.memo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx09MemoMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
