package kr.human.memo.service;

public interface TestService {
	String today();
}
