package kr.human.di.vo;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Component // 빈을 자동으로 등록하라!!!
public class  ApplicationUser {
	private String name="주인장";
}

