package kr.green.batch.vo;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class HanJaFieldSetMapper implements FieldSetMapper<HanJaVO>{

	@Override
	public HanJaVO mapFieldSet(FieldSet fieldSet) throws BindException {
		HanJaVO hanJaVO = new HanJaVO();
		hanJaVO.setIdx(fieldSet.readInt(0));
		hanJaVO.setH(fieldSet.readString(1));
		hanJaVO.setK(fieldSet.readString(2));
		hanJaVO.setM(fieldSet.readString(3));
		return hanJaVO;
	}

}
