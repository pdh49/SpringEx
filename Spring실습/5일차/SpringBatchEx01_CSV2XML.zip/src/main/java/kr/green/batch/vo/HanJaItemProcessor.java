package kr.green.batch.vo;

import org.springframework.batch.item.ItemProcessor;

public class HanJaItemProcessor implements ItemProcessor<HanJaVO, HanJaVO> {

	@Override
	public HanJaVO process(HanJaVO item) throws Exception {
		System.out.println("읽은 한자 : " + item);
		return item;
	}

}
