package kr.human.di.service;

import java.sql.SQLException;
import java.util.List;

import kr.human.di.vo.PeopleVO;

public interface PeopleService {
	//1.목록보기
	List<PeopleVO> selectList() throws SQLException;
	
	//2.저장하기
	boolean insert(PeopleVO peopleVO) throws SQLException;
	
	//3.수정하기
	boolean update(PeopleVO peopleVO) throws SQLException;
	
	//4.삭제하기
	boolean delete(int idx) throws SQLException;
	
}
