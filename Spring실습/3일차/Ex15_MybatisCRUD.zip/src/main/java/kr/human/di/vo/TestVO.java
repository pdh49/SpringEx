package kr.human.di.vo;

import lombok.Data;

@Data
public class TestVO {
	private String 	today;
	private int 	sum;
	private int  	mul;
	private int  	num1;
	private int  	num2;
}
