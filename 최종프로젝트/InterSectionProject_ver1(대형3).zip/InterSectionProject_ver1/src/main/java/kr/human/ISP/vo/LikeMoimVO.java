package kr.human.ISP.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LikeMoimVO {
	public int like_idx;
	public int user_idx;
	public int moim_idx;
}
