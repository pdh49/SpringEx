package kr.human.ISP.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.RequestContextUtils;

import kr.human.ISP.service.BoardService;
import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;
import kr.human.ISP.vo.UserVO;
import lombok.extern.slf4j.Slf4j;

@Controller 
@Slf4j
public class BoardController {
	
	@Autowired
	UserService userService;

	
	@Autowired
	BoardService boardService;
	
	
	@GetMapping("boardPage")
	public String boardPage() {
		return "boardPage";
	}
	@PostMapping("boardPage")
	public String boardPage2() {
		return "boardPage";
	}

	@SuppressWarnings("unchecked")
	@PostMapping(value="boardSubject")
	@ResponseBody
	public Map<String, Object> noticeBoardShow(HttpServletRequest request,Model model,@ModelAttribute CommVO commVO, @RequestParam Map<String,String> map) {
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if(flashMap!=null) {
			map = (Map<String, String>) flashMap.get("map");
			commVO.setP(Integer.parseInt(map.get("p")));
			commVO.setS(Integer.parseInt(map.get("s")));
			commVO.setB(Integer.parseInt(map.get("b")));
		}
		Map<String,Object> resultMap = new HashMap<String, Object>();
		String boardName = map.get("boardName");
		
		if(boardName.equals("inquiryResult")) {
			
		}else {
			PagingVO<BoardVO> pagingVO = boardService.selectBoardList(commVO,boardName);
			resultMap.put("pv", pagingVO);
			
		}
		resultMap.put("boardName", boardName);
		System.out.println("결과확인 : " + resultMap);
		return resultMap;
	}	
	
	//공지사항게시판보기
	@PostMapping(value = "boardviewPage")
	@ResponseBody
	public BoardVO boardView(HttpServletRequest request){
		String idx = request.getParameter("board_idx");
		int board_idx = Integer.parseInt(idx);
		BoardVO boardVO = null;
		boardVO = boardService.selectByIdx(board_idx);
		System.out.println(boardVO);
		return boardVO;
	}
	//공지사항 글쓰기버튼클릭시 내용전달
	@RequestMapping(value="noticeWrite_send", method=RequestMethod.POST)
    @ResponseBody
    public void checkId(HttpServletRequest request, Model model, HttpSession session,@ModelAttribute BoardVO boardVO) {
    	String board_subject = request.getParameter("noticeWirte_subject");
    	String board_content = request.getParameter("noticeWrite_content");
    	
    	//세션 로그인시?
    	//UserVO userVO = (UserVO)session.getAttribute("userVO");
    	//int user_idx = userVO.user_idx;
    	
    	int user_idx = 7;

    	boardVO.setBoard_subject(request.getParameter("noticeWirte_subject"));
    	boardVO.setBoard_content(request.getParameter("noticeWrite_content"));
    	boardVO.setUser_idx(user_idx);
    	boardVO.setBoard_category(request.getParameter("notice"));

    	boardService.insertBoard(boardVO);

    }
	

}
