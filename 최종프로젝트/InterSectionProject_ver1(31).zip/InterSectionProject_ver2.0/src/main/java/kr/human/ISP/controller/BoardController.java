package kr.human.ISP.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.RequestContextUtils;

import kr.human.ISP.service.BoardService;
import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.BoardCommentVO;
import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;
import kr.human.ISP.vo.UserVO;
import lombok.extern.slf4j.Slf4j;

@Controller 
@Slf4j
public class BoardController {
	
	@Autowired
	private UserService userService;

	
	@Autowired
	BoardService boardService;
	
	// Board Page 
	@GetMapping("boardPage")
	public String boardPage() {
		return "boardPage";
	}
	
	// 공지사항 목록 페이지
	@GetMapping("noticeList")
	public String boardList() {
		return "noticeList";
	}
	
	@GetMapping(value="inquiryResult")
	public String inquiryResult_P(HttpServletRequest request, @ModelAttribute BoardVO boardVO) {

		return "inquiryResult";
	}
	
	
	// 공지사항 목록 조회 Ajax
	@SuppressWarnings("unchecked")
	@PostMapping(value="boardSubject")
	@ResponseBody
	public Map<String, Object> noticeBoardShow(HttpServletRequest request,Model model,HttpSession session,
			@ModelAttribute CommVO commVO, @RequestParam Map<String,String> map) {
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if(flashMap!=null) {
			map = (Map<String, String>) flashMap.get("map");
			commVO.setP(Integer.parseInt(map.get("p")));
			commVO.setS(Integer.parseInt(map.get("s")));
			commVO.setB(Integer.parseInt(map.get("b")));
		}
		UserVO userVO = (UserVO) session.getAttribute("userVO");
		Map<String,Object> resultMap = new HashMap<String, Object>();
		String boardName = map.get("boardName");
		
		if(boardName.equals("inquiryResult")) {
			PagingVO<BoardVO> pagingVO =boardService.selectInquiryList(commVO,userVO.getUser_idx());
			for(BoardVO vo : pagingVO.getList()) {
				vo.setAnswer(boardService.selectCommentCountByBoardIdx(vo.getBoard_idx()));
			}
			resultMap.put("pv", pagingVO);
		}else {
			PagingVO<BoardVO> pagingVO = boardService.selectBoardList(commVO,boardName);
			resultMap.put("pv", pagingVO);
			
		}
		resultMap.put("boardName", boardName);
		System.out.println("결과확인 : " + resultMap);
		return resultMap;
	}
	
	
	// 공지사항 상세보기 페이지
	@GetMapping("noticeDetail/{board_idx}")
	public String boardDetail(HttpServletRequest request, @PathVariable("board_idx") int board_idx, Model model) {
		model.addAttribute("board_idx",board_idx);	
		System.out.println(board_idx);
		return "noticeDetail";
	}
	
	// 공지사항 상세조회 Ajax
	@RequestMapping(value = "noticeDetail")
	@ResponseBody 
	public BoardVO boardView(HttpServletRequest request){
		String idx = request.getParameter("board_idx");
		int board_idx = Integer.parseInt(idx);
		System.out.println("상세조회확인하기");
		BoardVO boardVO = null;
		boardVO = boardService.selectByIdx(board_idx);
		System.out.println(boardVO);
		return boardVO;
	}
	
	// 공지사항 등록 페이지
	@GetMapping("/noticeWrite")
	public String boardCreate(HttpServletRequest request, Model model) {
		return "noticeWrite";
	}
	
	// 공지사항 등록 Ajax
	@RequestMapping(value="noticeWrite_send", method=RequestMethod.POST)
    public String insertBoard(HttpServletRequest request, Model model, HttpSession session,@ModelAttribute BoardVO boardVO) {

    	//세션 로그인시?
    	//UserVO userVO = (UserVO)session.getAttribute("userVO");
    	//int user_idx = userVO.user_idx;
    	
    	int user_idx = 7;

    	boardVO.setBoard_subject(request.getParameter("noticeWirte_subject"));
    	boardVO.setBoard_content(request.getParameter("noticeWrite_content"));
    	boardVO.setUser_idx(user_idx);
    	boardVO.setBoard_category(request.getParameter("notice"));

    	boardService.insertBoard(boardVO);
    	return "noticeList";
    }
	
	
	// 공지사항 수정 페이지로 가기
	@GetMapping(value = "noticeUpdate/{board_idx}")
	public String boardUpdate(HttpServletRequest request, @PathVariable("board_idx") int board_idx, Model model,@ModelAttribute BoardVO boardVO) {
		boardVO.setBoard_idx(board_idx);
		boardVO = boardService.selectByIdx(board_idx);
		model.addAttribute(boardVO);
		return "noticeUpdateView";
	}
	//공지사항 수정하기(글업데이트)
	@PostMapping(value="noticeUpdate_send")
    public String updateBoard(HttpServletRequest request, HttpSession session,@ModelAttribute BoardVO boardVO) {

    	//세션 로그인시?
    	//UserVO userVO = (UserVO)session.getAttribute("userVO");
    	//int user_idx = userVO.user_idx;
    	String board_subject = request.getParameter("noticeWirte_subject");
    	String board_content = request.getParameter("noticeWrite_content");
    	String idx = request.getParameter("noticeWrite_idx");
    	int board_idx = Integer.parseInt(idx);


    	boardVO.setBoard_subject(board_subject);
    	boardVO.setBoard_content(board_content);
    	boardVO.setBoard_idx(board_idx);
    	boardVO.setBoard_category(request.getParameter("notice"));

    	boardService.updateBoard(boardVO);
    	return "redirect:noticeList";
    }
	
	
	// 공지사항 삭제하기 Ajax
	@RequestMapping(value = "boardDelete", method=RequestMethod.POST)
	@ResponseBody 
	public String boardDelete(HttpServletRequest request, @ModelAttribute BoardVO boardVO,@RequestParam String boardidx){
		int board_idx = Integer.parseInt(boardidx);
		boardVO.setBoard_idx(board_idx);
		boardService.deleteBoard(boardVO);
		return "삭제성공";
	}	
	
	// 1:1문의하기페이지
	@GetMapping(value="inquirySend")
	public String inquirySend(HttpServletRequest request, @ModelAttribute BoardVO boardVO) {
	
		return "inquirySend";
	}
	@PostMapping(value="inquirySend")
	public String inquirySendView(HttpServletRequest request, @ModelAttribute BoardVO boardVO,HttpSession session) {
		 
		return "inquirySend";
	}
	//  1:1 문의하기 글쓰기 저장
	@PostMapping(value="inquiryWrite_send")
	public String inquiryWrite_received(HttpServletRequest request, @ModelAttribute BoardVO boardVO,HttpSession session) {
		String board_subject = request.getParameter("inquiryWrite_subject");
		String board_content = request.getParameter("inquiryWrite_content");
		int user_idx = Integer.parseInt(request.getParameter("user_idx"));
		String inquiry = request.getParameter("inquiry");
		

		boardVO.setBoard_subject(board_subject);
		boardVO.setBoard_content(board_content);
		boardVO.setBoard_category(inquiry);
		boardVO.setUser_idx(user_idx);
		
		boardService.insertBoard(boardVO);
		
		return "boardList";
	}



	// 공지사항 수정 페이지로 가기
	@GetMapping(value = "inquiryDetail/{board_idx}")
	public String inquiryView(HttpServletRequest request, @PathVariable("board_idx") int board_idx, Model model,@ModelAttribute BoardVO boardVO) {
		
		boardVO  = boardService.selectByIdx(board_idx);
	
		
	
		model.addAttribute("test",board_idx);
		
		return "inquiryDetail";
	}
	// 나의 문의내역 뷰페이지 Ajax
	@PostMapping(value = "inquiryDetail")
	@ResponseBody
	public Map<String, Object> inquiryDetail(HttpServletRequest request,
			@ModelAttribute BoardVO boardVO,
			@ModelAttribute BoardCommentVO boardCommentVO,
			HttpSession session) {
		Map<String,Object> resultMap = new HashMap<>();
		
		int board_idx = Integer.parseInt(request.getParameter("board_idx"));
		boardVO  = boardService.selectByIdx(board_idx);
		UserVO userVO = (UserVO)session.getAttribute("userVO");
		resultMap.put("boardVO", boardVO);
		boardCommentVO = boardService.selectCommentBoard(board_idx, userVO.getUser_idx());
		resultMap.put("CommentContent",boardCommentVO.getComment_content());
		System.out.println("확인용 : " + resultMap);
		return resultMap;
		
	}

	@PostMapping(value = "inquiryReview_Insert")
	@ResponseBody
	public BoardCommentVO inquiryReview_Insert(HttpServletRequest request, Model model,@ModelAttribute BoardCommentVO boardCommentVO,HttpSession session) {
		
		int board_idx = Integer.parseInt(request.getParameter("board_idx"));
		String content = request.getParameter("content");
		System.out.println(board_idx);
		System.out.println(content);
		UserVO userVO = (UserVO) session.getAttribute("userVO");
		boardCommentVO.setBoard_idx(board_idx);
		boardCommentVO.setComment_content(content);
		boardCommentVO.setUser_idx(userVO.getUser_idx());
		boardService.insertBoardComment(boardCommentVO);
		
		//boardCommentVO =boardService.selectCommentBoard(board_idx, userVO.getUser_idx());
		
		
		return boardCommentVO;
		
	}

	

	
	
}
