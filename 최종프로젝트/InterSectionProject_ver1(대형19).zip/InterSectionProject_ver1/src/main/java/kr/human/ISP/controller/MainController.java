package kr.human.ISP.controller;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.RequestContextUtils;

import kr.human.ISP.service.ApplyService;
import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.MoimVO;
import kr.human.ISP.vo.PagingVO;
import kr.human.ISP.vo.UserVO;


public class MainController {


	
	/*
	@Autowired
	private UserService userService;
	
	@Autowired
	private ApplyService applyService;
	
	@RequestMapping(value = { "/", "/index" })
	public String index(Model model) {
		LocalDateTime today = LocalDateTime.now();
		Calendar cal  = Calendar.getInstance();
		int date = cal.get(Calendar.DATE);
		int dayofWeek = cal.get(Calendar.DAY_OF_WEEK)-1;
		
		String[] korDayOfWeek={"일","월","화","수","목","금","토"};
		
		model.addAttribute("today", today.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)));
		model.addAttribute("today_date",date);
		model.addAttribute("today_dayList",korDayOfWeek);
		model.addAttribute("today_day",dayofWeek);
		return "index";
	}
	
	@RequestMapping(value="mypage")
	public String mypage(Model model) throws SQLException {
		return "mypage";
	}
	
	@GetMapping(value="myMoim")
	public String MymoimGet() {
		return "redirect:/mypage";
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="myMoim")
	@ResponseBody
	public Map<String,?> myMoimPost(Model model,@RequestParam Map<String,String> map,
			@ModelAttribute CommVO commVO,HttpServletRequest request){
		System.out.println("--------------"+map + ": " +commVO);
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if(flashMap!=null) {
			map = (Map<String, String>) flashMap.get("map");
			commVO.setP(Integer.parseInt(map.get("p")));
			commVO.setS(Integer.parseInt(map.get("s")));
			commVO.setB(Integer.parseInt(map.get("b")));
		}
		
		
		
		UserVO userVO=null;
		String sortMenu=(String)map.get("sortMenu");
		PagingVO<MoimVO> pagingVO = null;
		Map<String,Object> resultMap = new HashMap<>(); // 결과 리턴 맵
		int user_idx=Integer.parseInt((String)map.get("user_idx"));
		List<Integer> list=mypageService.ApplyAgreeList(user_idx,sortMenu); // 신청테이블의 승인완료 인원수
		switch(sortMenu) {
			case "개설":
				userVO=userService.selectByIdx(user_idx);
				pagingVO=mypageService.createMoimList(commVO, user_idx);
				break;
			case "신청":
				userVO=userService.selectByIdx(user_idx);
				pagingVO=mypageService.applyMoimList(commVO, user_idx);
				break;
			case "참여중":
				userVO=userService.selectByIdx(user_idx);
				pagingVO=mypageService.joinMoimList(commVO, user_idx);
				break;
			case "찜한모임":
				userVO=userService.selectByIdx(user_idx);
				pagingVO=mypageService.likeMoimList(commVO, user_idx);
				break;
		}
		
		resultMap.put("user", userVO);
		resultMap.put("pv", pagingVO);
		resultMap.put("cv",commVO);
		resultMap.put("approve", list);
		resultMap.put("sortMenu", sortMenu);
		System.out.println(list);
		return resultMap;
	}
	@RequestMapping(value="apply")
	public String apply(Model model) throws SQLException {
		List<MoimVO> list = null;
		// 유저 아이디 세션값에서 가져오는 걸로 변경
		list = applyService.createMoimList(1);
		model.addAttribute("moimList",list);
		return "applyMember";
	}
	
	
	@RequestMapping(value = "/decorators/deco.html")
	   public String deco() {
	      return "decorators/deco";
	}
	
	*/
}
