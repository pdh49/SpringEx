package kr.human.ISP.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.ISP.service.BoardService;
import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.CommVO;

@Controller 
public class BoardController {
	
	@Autowired
	UserService userService;

	
	@Autowired
	BoardService boardService;

	@RequestMapping(value="/board/noticeBoard")
	public String noticeBoardShow(HttpServletRequest request,Model model,@ModelAttribute CommVO commVO, @RequestParam Map<String,Object> map) {
		System.out.println(commVO);
		
		boardService.selectList(commVO);
		
		return "/board/noticeBoard";
	}	
}
