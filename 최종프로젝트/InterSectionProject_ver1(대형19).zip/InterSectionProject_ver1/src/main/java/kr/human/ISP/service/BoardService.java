package kr.human.ISP.service;


import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;

public interface BoardService {
	//목록보기
	PagingVO<BoardVO> selectList(CommVO commVO);
	//내용보기
	BoardVO selectByIdx(int notice_idx,boolean isClick);
	//저장하기
	void insertNoticeBoard(BoardVO noticeBoardVO);
	//수정하기
	void updateNoticeBoard(BoardVO noticeBoardVO);
	//삭제하기
	void deleteNoticeBoard(BoardVO noticeBoardVo);
}
