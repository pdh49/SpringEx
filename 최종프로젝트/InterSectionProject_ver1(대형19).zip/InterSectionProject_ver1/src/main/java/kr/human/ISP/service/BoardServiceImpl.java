package kr.human.ISP.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.human.ISP.dao.BoardDAO;
import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;

@Service("boardService")
@Transactional
public class BoardServiceImpl implements BoardService{

	@Autowired
	private BoardDAO boardDAO;
	
	@Override
	public PagingVO<BoardVO> selectList(CommVO commVO) {
		System.out.println("확인할게요 : " + commVO);
		PagingVO<BoardVO> pv = null;
		
		
		return null;
	}

	@Override
	public BoardVO selectByIdx(int notice_idx, boolean isClick) {
		return null;
	}

	@Override
	public void insertNoticeBoard(BoardVO noticeBoardVO) {
		
	}

	@Override
	public void updateNoticeBoard(BoardVO noticeBoardVO) {
		
	}

	@Override
	public void deleteNoticeBoard(BoardVO noticeBoardVo) {
		
	}


}
