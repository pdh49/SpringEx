package kr.human.ISP.vo;

import java.sql.Date;

public class TestVO {
	Date today;
}
