package kr.human.ISP.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.UserVO;

@Controller
public class MainController {

	@Autowired
	UserService userService;


	@RequestMapping(value = { "/", "/index" })
	public String index(Model model) {
		LocalDateTime today = LocalDateTime.now();
		Calendar cal  = Calendar.getInstance();
		int date = cal.get(Calendar.DATE);
		int dayofWeek = cal.get(Calendar.DAY_OF_WEEK)-1;

		String[] korDayOfWeek={"일","월","화","수","목","금","토"};

		model.addAttribute("today", today.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)));
		model.addAttribute("today_date",date);
		model.addAttribute("today_dayList",korDayOfWeek);
		model.addAttribute("today_day",dayofWeek);
		return "index";
	}

	@RequestMapping(value="mypage")
	public String mypage(Model model) {
		return "mypage";
	}

	@RequestMapping(value = "/decorators/deco.html")
	   public String deco() {
	      return "decorators/deco";
	}

	@RequestMapping(value="select")
	public String select(Model model) {
		return "select";
	}


	//대형구현
	@RequestMapping(value="login")
	public String login(Model model) {
		return "login";
	}
	@RequestMapping(value="signUp3")
	public String signup3(Model model) {
		return "signUp3";
	}

	@GetMapping("signUp")
	public String signUpForm() {
		return "signUp";
	}

    @RequestMapping(value="signUp")
    public String signUp(UserVO userVo) {
        userService.insert(userVo);
        return "signUp_Ct"; //로그인 구현 예정
    }

	@GetMapping("signUp_Ct")
	public String signUpForm2() {
		return "signUp_Ct";
	}
    @RequestMapping(value="signUp_Ct")
	public String signUp_Ct(Model model) {
    	int idx;
    	idx = userService.findIdx();
    	System.out.println(idx);
		return "signUp_Ct";
	}

    @RequestMapping(value="sendCt")
    @ResponseBody
	public String check(HttpServletRequest request,Model model) {
    	String[] selectItem = request.getParameterValues("selectItem");
    	int size = selectItem.length;

    	List<String> data = new ArrayList<>();
    	for(int i=0; i<size; i++) {
    		System.out.println("js에서 받은 msg: "+i+ ": "+ selectItem[i]);
    		data.add(selectItem[i]);
    	}
    	model.addAttribute("data",data);
    	System.out.println("-----------------------");

		return "signUp_Ct";
	}

    //회원가입 여부확인
    @RequestMapping(value="emailCheck", method=RequestMethod.POST)
    @ResponseBody
    public int checkMail(HttpServletRequest request, Model model) {

    	String eamil = request.getParameter("ts");
    	System.out.println(eamil);
    	int idx = 0;
    	idx = userService.idCheck(eamil);
    	return idx;
    }

    //아이디 찾기
    @RequestMapping(value="idCheck", method=RequestMethod.POST)
    @ResponseBody
    public String checkId(HttpServletRequest request, Model model) {
    	String idOk = "";
    	String eamil = request.getParameter("mail");
    	String phone = request.getParameter("phone");
    	System.out.println(eamil);
    	System.out.println(phone);
    	idOk = userService.findid(eamil, phone);
    	return idOk;
    }

    //비밀번호 찾기
    /*
    @RequestMapping(value="psFind", method=RequestMethod.POST)
    @ResponseBody
    public int checkPs(HttpServletRequest request, Model model) {

    	String mail = request.getParameter("mail");
    	String name = request.getParameter("name");
    	int checkOk = userService.userInfoCheck(mail, name);
    	if(checkOk == 1) {
    		System.out.println("정보있으면 1 ->" +checkOk);
    		return checkOk;
    	}else {
    		System.out.println("정보가 다르면 0 -> " + checkOk);
    		return checkOk;
    	}
   
    		
    }*/

	@RequestMapping(value="infoFind")
	public String infoFind(Model model) {
		return "infoFind";
	}


}

