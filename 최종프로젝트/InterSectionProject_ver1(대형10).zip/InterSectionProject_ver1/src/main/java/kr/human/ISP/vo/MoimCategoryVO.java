package kr.human.ISP.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class MoimCategoryVO {
	public int moim_category_idx;
	public int moim_idx;
	public int category_idx;
}
