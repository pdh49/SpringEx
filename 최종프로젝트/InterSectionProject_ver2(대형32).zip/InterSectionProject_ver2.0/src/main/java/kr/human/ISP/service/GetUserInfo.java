package kr.human.ISP.service;

public class GetUserInfo {
	
}
