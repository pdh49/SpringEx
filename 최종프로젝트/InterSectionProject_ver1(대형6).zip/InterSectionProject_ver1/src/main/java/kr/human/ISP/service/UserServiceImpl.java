package kr.human.ISP.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.human.ISP.dao.UserDAO;
import kr.human.ISP.vo.UserVO;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	UserDAO userDAO;
	
	
	
	@Override
	public boolean insert(UserVO userVO) {
		boolean result = false;
		if(userVO !=null){
			try {
				userDAO.insert(userVO);
				result = true;
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}



	@Override
	public int idCheck(String id) {

		int cnt = 0;
		if(id != null) {
			try {
				cnt = userDAO.selectUseridCount(id);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cnt;
	}






}
