package kr.human.ISP.service;

import kr.human.ISP.vo.UserVO;

public interface UserService {
	
	boolean insert(UserVO userVO); // 회원저장
	
	
	
}
