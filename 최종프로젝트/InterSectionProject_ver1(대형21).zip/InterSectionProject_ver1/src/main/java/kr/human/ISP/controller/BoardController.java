package kr.human.ISP.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.ISP.service.BoardService;
import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;

@Controller 
public class BoardController {
	
	@Autowired
	UserService userService;

	
	@Autowired
	BoardService boardService;
	

	@RequestMapping(value="/board/noticeBoard")
	public Map<String, Object> noticeBoardShow(HttpServletRequest request,Model model,@ModelAttribute CommVO commVO, @RequestParam Map<String,Object> map) {
		System.out.println(commVO);
		
		Map<String,Object> BoardListMap = new HashMap<>();
		PagingVO<BoardVO> pagingVO = boardService.selectNoticeList(commVO);
		BoardListMap.put("pv", pagingVO);
		BoardListMap.put("cv", commVO);
		model.addAttribute("BoardListMap",BoardListMap);
		return BoardListMap;
	}	
}
