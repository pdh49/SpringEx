package kr.human.ISP.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.human.ISP.dao.BoardDAO;
import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;

@Service("boardService")
@Transactional
public class BoardServiceImpl implements BoardService{

	@Autowired
	private BoardDAO boardDAO;
	
	@Override
	public PagingVO<BoardVO> selectNoticeList(CommVO commVO) {
		System.out.println("확인할게요 : " + commVO);
		PagingVO<BoardVO> pagingVO = null;
		String notice = "notice";
		try {
			
			int totalCount = boardDAO.selectCountByCategory(notice);
			System.out.println("게시판갯수 : " + totalCount);
			pagingVO = new PagingVO<>(totalCount, commVO.getP(), commVO.getS(), commVO.getB());
			HashMap<String, Object> hashMap = new HashMap<>();
			hashMap.put("startNo", pagingVO.getStartNo());
			hashMap.put("endNo", pagingVO.getEndNo());
			hashMap.put("board_category", notice);
			List<BoardVO> list = boardDAO.selectListByCategory(hashMap);
			System.out.println("확인222222 : " + list);
			pagingVO.setList(list);
			System.out.println("최종결과  : " + pagingVO);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pagingVO;
	}

	@Override
	public BoardVO selectByIdx(int notice_idx, boolean isClick) {
		return null;
	}

	@Override
	public void insertNoticeBoard(BoardVO noticeBoardVO) {
		
	}

	@Override
	public void updateNoticeBoard(BoardVO noticeBoardVO) {
		
	}

	@Override
	public void deleteNoticeBoard(BoardVO noticeBoardVo) {
		
	}


}
