package kr.human.ISP.service;

import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.reactive.WebFluxProperties.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.human.ISP.dao.CategoryDAO;
import kr.human.ISP.dao.UserCategoryDAO;
import kr.human.ISP.dao.UserDAO;
import kr.human.ISP.vo.UserVO;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	UserDAO userDAO;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	UserCategoryDAO userCategoryDAO;

	@Override
	public boolean insert(UserVO userVO) {
		boolean result = false;
		if(userVO !=null){
			try {
				userDAO.insert(userVO);
				result = true;
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}


	@Override
	public int idCheck(String id) {

		int cnt = 0;
		if(id != null) {
			try {
				cnt = userDAO.selectUseridCount(id);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cnt;
	}


	@Override
	public int findIdx() {
		int idx =0;
			try {
				idx = userDAO.selectUserIdx();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return idx;
	}



	@Override
	public String findid(String user_name, String user_phone) {
		String idOk ="";
		if(user_name != null && user_phone !=null) {
		try {
			idOk = userDAO.selectFindId(user_name, user_phone);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}
		return idOk;
	}


	@Override
	public int userInfoCheck(String user_id, String user_name) {
		int count = 0;
			try {
				count = userDAO.serInfoCheck(user_id, user_name);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return count;
	}


	@Override
	public void UserTempPassword(String user_id, String user_name, String tempPassword) {
		String user_pwd = tempPassword;
			try {
				 userDAO.updateTempPassword(user_id, user_name, user_pwd);
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}


	@Override
	public int selectCategoryIdxByScName(String sc_name) {
		int categoryIdx = 0;
		try {
			categoryIdx = categoryDAO.selectCategoryIdxByScName(sc_name);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return categoryIdx;
	}


	@Override
	public void insertUserCategory(HashMap<String, Integer> map) {
		try {
			userCategoryDAO.insert(map);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	//로그인하기
	@Override
	public boolean checkUserLogin(HashMap<String, String> map) {
		
		boolean flag = false;
		try {
			UserVO userVO = userDAO.selectByUserid(map.get("user_id"));
			if(userVO != null)
			{
				if(userVO.getUser_pwd().equals(map.get("user_pwd"))) {
					flag = true;
					
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}


	@Override
	public UserVO selectById(String user_id) {
		
		try {
			
			UserVO userVO = userDAO.selectByUserid(user_id);
			if(userVO != null)
				return userVO;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}











}
