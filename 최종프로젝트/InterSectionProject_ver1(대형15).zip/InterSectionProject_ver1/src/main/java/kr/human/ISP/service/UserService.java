package kr.human.ISP.service;

import java.util.HashMap;

import io.swagger.models.auth.In;
import kr.human.ISP.vo.UserVO;

public interface UserService {

	boolean insert(UserVO userVO); // 회원저장
	public int idCheck(String id); // 이메일 체크
	public int findIdx(); //유저가입자 idx체크
	public String findid(String user_name,String user_phone); // 유저 아이디 찾기
	public int userInfoCheck(String user_id, String user_name); // 유저 비밀번호찾기시 정보확인
	public void UserTempPassword(String user_id, String user_name,String tempPassword); // 유저임시비밀번호 생성
	int selectCategoryIdxByScName(String sc_name); // 소분류 카테고리 idx가져오기
	void insertUserCategory(HashMap<String, Integer> map); // 회원가입시 유저 카테고리 저장
	public boolean checkUserLogin(HashMap<String, String> map); // 유저 로그인 확인
	public UserVO selectById(String user_id); // 유저 회원정보 가져오기
	
}
