package kr.human.ISP.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MessageDTO {
	public String msg;
	public String Result;

}
