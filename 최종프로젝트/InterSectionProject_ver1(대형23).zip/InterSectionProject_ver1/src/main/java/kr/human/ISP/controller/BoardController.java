package kr.human.ISP.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.RequestContextUtils;

import kr.human.ISP.service.BoardService;
import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.BoardVO;
import kr.human.ISP.vo.CommVO;
import kr.human.ISP.vo.PagingVO;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

@Controller 
@Slf4j
public class BoardController {
	
	@Autowired
	UserService userService;

	
	@Autowired
	BoardService boardService;
	
	
	@GetMapping("boardPage")
	public String boardPage() {
		return "boardPage";
	}

	@SuppressWarnings("unchecked")
	@PostMapping(value="boardSubject")
	@ResponseBody
	public Map<String, Object> noticeBoardShow(HttpServletRequest request,Model model,@ModelAttribute CommVO commVO, @RequestParam Map<String,String> map) {
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if(flashMap!=null) {
			map = (Map<String, String>) flashMap.get("map");
			commVO.setP(Integer.parseInt(map.get("p")));
			commVO.setS(Integer.parseInt(map.get("s")));
			commVO.setB(Integer.parseInt(map.get("b")));
		}
		Map<String,Object> resultMap = new HashMap<String, Object>();
		String boardName = map.get("boardName");
		
		if(boardName.equals("inquiryResult")) {
			
		}else {
			PagingVO<BoardVO> pagingVO = boardService.selectBoardList(commVO,boardName);
			resultMap.put("pv", pagingVO);			
		}
		System.out.println("결과확인 : " + resultMap);
		return resultMap;
	}	
	
	@RequestMapping(value="boardView")
	public String boardView(HttpServletRequest request){
		String board_idx = request.getParameter("viewPage");
		System.out.println(board_idx);
		return "dd";
	}
}
