package kr.human.ISP.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.human.ISP.service.UserService;
import kr.human.ISP.vo.MessageDTO;
import kr.human.ISP.vo.UserVO;

@Controller
public class MainController {

	@Autowired
	UserService userService;
	
	
	@RequestMapping(value = { "/", "/index" })
	public String index(Model model) {
		LocalDateTime today = LocalDateTime.now();
		Calendar cal  = Calendar.getInstance();
		int date = cal.get(Calendar.DATE);
		int dayofWeek = cal.get(Calendar.DAY_OF_WEEK)-1;
		
		String[] korDayOfWeek={"일","월","화","수","목","금","토"};
		
		model.addAttribute("today", today.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)));
		model.addAttribute("today_date",date);
		model.addAttribute("today_dayList",korDayOfWeek);
		model.addAttribute("today_day",dayofWeek);
		return "index";
	}
	
	@RequestMapping(value="mypage")
	public String mypage(Model model) {
		return "mypage";
	}

	@RequestMapping(value = "/decorators/deco.html")
	   public String deco() {
	      return "decorators/deco";
	}

	@RequestMapping(value="select")
	public String select(Model model) {
		return "select";
	}
	@RequestMapping(value="signUp2")
	public String signUp(Model model) {
		return "signUp2";
	}
	@RequestMapping(value="login")
	public String login(Model model) {
		return "login";
	}
	@RequestMapping(value="signUp3")
	public String signup3(Model model) {
		return "signUp3";
	}
	@GetMapping("signUp")
	public String signUpForm() {
		return "signUp";
	}
    @PostMapping("/signUp")
    public String signUp(UserVO userVo) {
        userService.insert(userVo);
        return "redirect:/signUp2"; //로그인 구현 예정
    }
    @RequestMapping(value = "/dataSend",method = RequestMethod.POST)
    public String dataSend(Model model, MessageDTO dto){
        model.addAttribute("msg",dto.getResult()+"/ this is the value sent by the server ");
        return "signUp3 :: #resultDiv";
    }

}

