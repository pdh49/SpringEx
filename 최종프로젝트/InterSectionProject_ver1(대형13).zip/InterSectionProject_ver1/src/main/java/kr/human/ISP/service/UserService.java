package kr.human.ISP.service;

import kr.human.ISP.vo.UserVO;

public interface UserService {

	boolean insert(UserVO userVO); // 회원저장
	public int idCheck(String id); // 이메일 체크
	public int findIdx(); //유저가입자 idx체크
	public String findid(String user_name,String user_phone); // 유저 아이디 찾기
	public int userInfoCheck(String user_id, String user_name); // 유저 비밀번호찾기시 정보확인
	public void UserTempPassword(String user_id, String user_name,String tempPassword); // 유저임시비밀번호 생성

}
